import os, json, time, threading
from collections import defaultdict, deque
from datetime import timedelta
from functools import wraps

import discord
from discord import app_commands
from discord.ext import commands
from flask import Flask, request, redirect, session, render_template, jsonify, abort

# Configure these environment variables before starting:
# DISCORD_TOKEN, ADMIN_PASSWORD, SECRET_KEY
TOKEN = os.getenv("DISCORD_TOKEN", "")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-before-deploying")
PORT = int(os.getenv("PORT", "8080"))
DATA_FILE = "dashboard_data.json"

if not TOKEN or not ADMIN_PASSWORD:
    print("WARNING: Set DISCORD_TOKEN and ADMIN_PASSWORD in your host's environment variables.")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

web = Flask(__name__)
web.secret_key = SECRET_KEY
web.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

default_data = {
    "config": {
        "antispam": True, "filter_links": False, "mention_limit": 5,
        "spam_count": 5, "spam_window": 7, "timeout_minutes": 10,
        "log_channel_id": ""
    },
    "logs": []
}
data_lock = threading.Lock()
message_history = defaultdict(lambda: deque())
warn_counts = defaultdict(int)

def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        return loaded
    except (OSError, ValueError):
        return json.loads(json.dumps(default_data))

data = load_data()

def save_data():
    with data_lock:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

def add_log(guild, action, target="—", moderator="Sistema", details=""):
    entry = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "guild": str(guild), "action": action, "target": str(target),
        "moderator": str(moderator), "details": str(details)[:300]
    }
    with data_lock:
        data["logs"].insert(0, entry)
        del data["logs"][500:]
    save_data()
    cfg_id = data["config"].get("log_channel_id", "")
    if cfg_id and bot.is_ready():
        channel = bot.get_channel(int(cfg_id)) if cfg_id.isdigit() else None
        if channel:
            try:
                bot.loop.create_task(channel.send(
                    f"**{action}** · alvo: {target} · responsável: {moderator}\n{details}"[:1900]
                ))
            except Exception:
                pass

def logged_in():
    return session.get("logged_in") is True

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not logged_in():
            if request.path.startswith("/api/"):
                return jsonify({"error": "Autenticação necessária"}), 401
            return redirect("/login")
        return fn(*args, **kwargs)
    return wrapped

@web.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        if request.form.get("password", "") == ADMIN_PASSWORD:
            session.clear()
            session["logged_in"] = True
            return redirect("/")
        error = "Palavra-passe incorreta."
    return render_template("login.html", error=error)

@web.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect("/login")

@web.route("/")
@login_required
def home():
    return render_template("index.html", config=data["config"], logs=data["logs"][:60],
                           bot_ready=bot.is_ready(), guilds=len(bot.guilds))

@web.route("/api/config", methods=["POST"])
@login_required
def update_config():
    body = request.get_json(silent=True) or {}
    cfg = data["config"]
    for key in ("antispam", "filter_links"):
        if key in body:
            cfg[key] = bool(body[key])
    for key, low, high in (("mention_limit", 2, 20), ("spam_count", 3, 15),
                           ("spam_window", 3, 60), ("timeout_minutes", 1, 10080)):
        if key in body:
            try:
                cfg[key] = max(low, min(high, int(body[key])))
            except (TypeError, ValueError):
                return jsonify({"error": f"Valor inválido: {key}"}), 400
    if "log_channel_id" in body:
        value = str(body["log_channel_id"]).strip()
        if value and not value.isdigit():
            return jsonify({"error": "O ID do canal deve conter apenas números."}), 400
        cfg["log_channel_id"] = value
    save_data()
    return jsonify({"ok": True, "config": cfg})

def get_member(guild_id, member_id):
    if not str(guild_id).isdigit() or not str(member_id).isdigit():
        abort(400, "IDs inválidos.")
    guild = bot.get_guild(int(guild_id))
    if not guild:
        abort(404, "Servidor não encontrado pelo bot.")
    member = guild.get_member(int(member_id))
    if member is None:
        abort(404, "Membro não encontrado. Ative Server Members Intent e confirme que o bot está no servidor.")
    return guild, member

def dashboard_actor(guild):
    # The dashboard uses a separate admin password, so action attempts are still
    # constrained by the bot's Discord permissions and role hierarchy.
    if not guild.me or not guild.me.guild_permissions.manage_guild:
        abort(403, "O bot precisa da permissão Gerir servidor.")
    return "Administrador do dashboard"

@web.route("/api/action", methods=["POST"])
@login_required
def moderation_action():
    body = request.get_json(silent=True) or {}
    action = str(body.get("action", "")).lower()
    guild_id, member_id = str(body.get("guild_id", "")), str(body.get("member_id", ""))
    reason = str(body.get("reason", "Ação pelo dashboard"))[:400]
    guild, member = get_member(guild_id, member_id)
    actor = dashboard_actor(guild)
    if member.id == guild.owner_id or member.top_role >= guild.me.top_role:
        return jsonify({"error": "Hierarquia de cargos impede esta ação."}), 403
    try:
        if action == "ban":
            if not guild.me.guild_permissions.ban_members: abort(403, "Falta permissão Banir membros.")
            bot.loop.create_task(member.ban(reason=reason, delete_message_seconds=0))
            label = "Ban"
        elif action == "kick":
            if not guild.me.guild_permissions.kick_members: abort(403, "Falta permissão Expulsar membros.")
            bot.loop.create_task(member.kick(reason=reason))
            label = "Kick"
        elif action == "timeout":
            if not guild.me.guild_permissions.moderate_members: abort(403, "Falta permissão Moderar membros.")
            minutes = int(body.get("minutes", data["config"]["timeout_minutes"]))
            minutes = max(1, min(minutes, 10080))
            bot.loop.create_task(member.timeout(timedelta(minutes=minutes), reason=reason))
            label = f"Timeout {minutes} min"
        elif action == "warn":
            warn_counts[(guild.id, member.id)] += 1
            label = "Aviso"
        else:
            return jsonify({"error": "Ação não reconhecida."}), 400
        add_log(guild.name, label, f"{member} ({member.id})", actor, reason)
        return jsonify({"ok": True, "message": f"{label} solicitado para {member}. Verifica os logs do bot."})
    except discord.Forbidden:
        return jsonify({"error": "O Discord recusou a ação. Verifica as permissões e a hierarquia de cargos."}), 403
    except Exception as exc:
        return jsonify({"error": f"Não foi possível executar a ação: {exc}"}), 500

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"Bot online: {bot.user}; {len(synced)} comandos slash sincronizados.")
    except Exception as e:
        print("Falha ao sincronizar comandos:", e)

@bot.event
async def on_message(message):
    if message.author.bot or not message.guild:
        return
    cfg = data["config"]
    member = message.author
    if not isinstance(member, discord.Member):
        return
    if member.guild_permissions.manage_messages:
        return

    if cfg.get("antispam", True):
        key = (message.guild.id, member.id)
        now = time.time()
        history = message_history[key]
        history.append((now, message.content))
        while history and now - history[0][0] > int(cfg.get("spam_window", 7)):
            history.popleft()
        repeated = len(history) >= int(cfg.get("spam_count", 5)) and len({x[1] for x in list(history)[-int(cfg.get("spam_count", 5)): ]}) <= 2
        mentions = len(message.mentions) + len(message.role_mentions)
        too_many_mentions = mentions >= int(cfg.get("mention_limit", 5))
        if repeated or too_many_mentions:
            try:
                await message.delete()
            except discord.Forbidden:
                pass
            try:
                await member.timeout(timedelta(minutes=int(cfg.get("timeout_minutes", 10))),
                                     reason="Proteção automática contra spam/menções")
                add_log(message.guild.name, "AutoMod timeout", f"{member} ({member.id})",
                        "Sistema", "Spam ou excesso de menções")
            except discord.Forbidden:
                add_log(message.guild.name, "AutoMod falhou", str(member), "Sistema",
                        "Faltam permissões para timeout.")
            return

    if cfg.get("filter_links", False) and ("http://" in message.content.lower() or "https://" in message.content.lower()):
        try:
            await message.delete()
            add_log(message.guild.name, "Link removido", f"{member} ({member.id})",
                    "Sistema", "Filtro de links ativado")
        except discord.Forbidden:
            pass

@bot.event
async def on_member_join(member):
    add_log(member.guild.name, "Entrada", f"{member} ({member.id})", "Sistema", "Membro entrou")

@bot.event
async def on_member_remove(member):
    add_log(member.guild.name, "Saída", f"{member} ({member.id})", "Sistema", "Membro saiu")

@bot.event
async def on_message_delete(message):
    if message.guild and not message.author.bot:
        add_log(message.guild.name, "Mensagem apagada", f"{message.author} ({message.author.id})",
                "Evento", (message.content or "[sem conteúdo disponível]")[:250])

@bot.event
async def on_message_edit(before, after):
    if after.guild and not after.author.bot and before.content != after.content:
        add_log(after.guild.name, "Mensagem editada", f"{after.author} ({after.author.id})",
                "Evento", f"Antes: {before.content[:100]} | Depois: {after.content[:100]}")

@bot.tree.command(name="warn", description="Regista um aviso para um membro")
@app_commands.checks.has_permissions(moderate_members=True)
async def warn_command(interaction: discord.Interaction, membro: discord.Member, motivo: str = "Sem motivo indicado"):
    warn_counts[(interaction.guild_id, membro.id)] += 1
    add_log(interaction.guild.name, "Aviso", f"{membro} ({membro.id})",
            str(interaction.user), motivo)
    await interaction.response.send_message(f"⚠️ Aviso registado para {membro.mention}.", ephemeral=True)

def run_web():
    web.run(host="0.0.0.0", port=PORT, debug=False, use_reloader=False)

if __name__ == "__main__":
    threading.Thread(target=run_web, daemon=True).start()
    if TOKEN:
        bot.run(TOKEN)
    else:
        print("Define DISCORD_TOKEN para iniciar o bot Discord.")
        while True:
            time.sleep(3600)
