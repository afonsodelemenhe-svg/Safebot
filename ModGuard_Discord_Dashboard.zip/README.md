# ModGuard — Dashboard de moderação Discord

Dashboard web em português com tema escuro/roxo, bot `discord.py`, antispam, filtro opcional de links, timeout automático, ações manuais (aviso, timeout, kick, ban) e logs.

## Requisitos
- Python 3.10+
- Aplicação criada em https://discord.com/developers/applications
- Bot convidado para o servidor com permissões apropriadas

## Configuração
1. Cria uma aplicação no Discord Developer Portal e adiciona um bot.
2. Em **Bot**, ativa **Server Members Intent** e **Message Content Intent**.
3. Convida o bot para o servidor com `View Channels`, `Send Messages`, `Read Message History`, `Manage Messages`, `Moderate Members`, `Kick Members`, `Ban Members` e `View Audit Log` conforme as funções que pretendes usar. Não lhe dês `Administrator` se não for necessário.
4. Instala dependências:
   ```bash
   pip install -r requirements.txt
   ```
5. Copia `.env.example` para `.env` e define as variáveis de ambiente no teu alojamento. Este exemplo não carrega `.env` automaticamente; para usar um ficheiro `.env`, instala `python-dotenv` e acrescenta `from dotenv import load_dotenv; load_dotenv()` no início de `app.py`, ou configura as variáveis no painel do host.
6. Inicia:
   ```bash
   python app.py
   ```
7. Abre `http://localhost:8080` ou o endereço HTTPS fornecido pelo host.

## Segurança importante
- Usa HTTPS quando publicares o dashboard na Internet.
- Define `ADMIN_PASSWORD` e `SECRET_KEY` fortes e únicas.
- Guarda `DISCORD_TOKEN` apenas nas variáveis secretas do alojamento; nunca o coloques no HTML, GitHub público ou screenshots.
- O login é uma palavra-passe única de administrador, não autenticação Discord OAuth. Usa-o apenas num ambiente privado/experimental; antes de expor publicamente, adiciona OAuth2, proteção CSRF, limitação de tentativas e controlos de acesso por servidor.
- O canal de logs pode conter conteúdo de mensagens. Restringe o acesso e informa os membros sobre a política de registos.
- O bot respeita a hierarquia de cargos do Discord. As ações podem falhar se o cargo do bot estiver abaixo do alvo.
- Os logs são guardados localmente em `dashboard_data.json`; num host efémero, usa armazenamento persistente.

## Notas
- O filtro de links é simples e opcional; não substitui uma solução antiphishing.
- O sistema antispam usa limites básicos configuráveis; testa primeiro num servidor de teste.
- Ações de ban/kick/timeout são executadas pelo bot. Usa apenas para moderar servidores que administras.
